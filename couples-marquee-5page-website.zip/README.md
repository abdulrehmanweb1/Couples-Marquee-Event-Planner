# Couples Marquee — 5-page website concept

Pages:
1. `index.html` — Home
2. `services.html` — Services
3. `about.html` — Our approach
4. `gallery.html` — Filterable inspiration gallery
5. `contact.html` — Contact and WhatsApp enquiry form

Shared assets are in `assets/css/style.css` and `assets/js/site.js`.

## Preview
Open `index.html` in a browser. Internet access is required for Google Fonts and remote concept photos.

## Deploy to GitHub + Vercel
1. Extract this ZIP.
2. Create a GitHub repository named `couples-marquee-demo`.
3. Upload all files and folders to the repository root. The repository root should contain `index.html`, `services.html`, `about.html`, `gallery.html`, `contact.html`, `assets/`, and `README.md`.
4. In Vercel, choose Add New → Project and import that GitHub repository.
5. Select Framework Preset: Other. Leave build command blank; deploy as a static site.
6. After deployment, Vercel provides the live URL.

## Before a real launch
This is an independent demo concept, not an approved official site. Photos are stock/concept photos and must be replaced with authorised venue photos. Confirm venue details, social URLs, email, hours, capacity, package information, and all claims with the business. The enquiry form opens WhatsApp and does not store submissions or confirm bookings.
